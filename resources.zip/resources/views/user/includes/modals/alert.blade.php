<div class="modal fade" id="alert-modal">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content rounded-0">
            <div class="modal-header alert-alert px-3 rounded-0 bg-danger">
                <h6 class="text-light mb-0"><i class="fas fa-cog"></i> <span class="top-title"></span></h6>
                <button aria-label="Close" class="close" data-dismiss="modal" type="button">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-3">
                
            </div>
        </div>
    </div>
</div>
