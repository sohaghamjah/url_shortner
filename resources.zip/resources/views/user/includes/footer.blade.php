  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Develop By <a href="#">Sohag Hamjah</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <a href="#">Sohag Hamjah</a>.</strong> All rights reserved.
  </footer>