<div class="alert alert-primary text-center" role="alert">
    No Data Found!    
</div>