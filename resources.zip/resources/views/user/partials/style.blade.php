<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome Icons -->
<link rel="stylesheet" href="{{ asset('public/asset/') }}/css/fontawesome.all.min.css">
<!-- Select 2 -->
<link rel="stylesheet" href="{{ asset('public/asset/css/select2.min.css') }}">
<!-- Theme style -->
<link rel="stylesheet" href="{{ asset('public/asset/') }}/css/adminlte.min.css">
<!-- Custom style -->
<!-- DataTables -->
<link href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.bootstrap4.min.css" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('public/asset/') }}/css/style.css">
@stack('style')